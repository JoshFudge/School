import math as m
def area(radius):
    
    c_area = pow(radius,2)
    c_area = c_area *m.pi
    c_area = round(c_area,2)
    print(c_area, "units*2")

(area(int(1)))
(area(int(2)))
(area(int(3)))