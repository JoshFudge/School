full_path = "/home/joel/Documents/songs/future_days.md"


full_path = full_path.split("/")
full_path = (" --> ").join(full_path[1:10])
print(full_path)